// Lab2.java

package ca.mcgill.ecse211.lab3;

import ca.mcgill.ecse211.lab3.Driver;
import ca.mcgill.ecse211.lab3.DriveUS;
import ca.mcgill.ecse211.lab3.UltrasonicPoller;
import lejos.hardware.Button;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;

public class Lab3 {


	
	
	
	
	static final EV3LargeRegulatedMotor leftMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("B"));

	static final EV3LargeRegulatedMotor rightMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("C"));

	static final EV3LargeRegulatedMotor eyesMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("D"));
	
	static final Port usPort = LocalEV3.get().getPort("S2");

	
	public static final double WHEEL_RADIUS = 2.1;
	public static final double TRACK = 15.55;	//TODO: check the actual width of our robot
	
	
	
	
	

	
	
	
	public static void main(String[] args) {
		
		int buttonChoice;
		
		//TO MAKE THE US POLLER WORK WE DECLARE THESE VARIABLES
	@SuppressWarnings("resource")							    // Because we don't bother to close this resource
	SensorModes ultrasonicSensor = new EV3UltrasonicSensor(usPort);		// usSensor is the instance
	SampleProvider usDistance = ultrasonicSensor.getMode("Distance");	// usDistance provides samples from this instance
	float[] usData = new float[1];		// usData is the buffer in which data are returned
	UltrasonicPoller usPoller = null;

		final TextLCD t = LocalEV3.get().getTextLCD();
		Odometer odometer = new Odometer(leftMotor, rightMotor);
		OdometryDisplay odometryDisplay = new OdometryDisplay(odometer, t);
		
		
		
		do {
			// clear the display
			t.clear();


			// ask the user whether the motors should drive with obstacles or not
			t.drawString("< Left | Right >", 0, 0);
			t.drawString("with   | with no ", 0, 1);
			t.drawString(" obst- | obst-  ", 0, 2);
			t.drawString(" acles | acles  ", 0, 3);
			t.drawString("       |        ", 0, 4);

			buttonChoice = Button.waitForAnyPress();

			//Driver driver = new Driver(leftMotor, rightMotor, WHEEL_RADIUS, WHEEL_RADIUS, TRACK, odometer);
			
			
			
		} while (buttonChoice != Button.ID_LEFT
				&& buttonChoice != Button.ID_RIGHT);
			if (buttonChoice == Button.ID_LEFT) {
				DriveUS driveUS = new DriveUS(leftMotor, rightMotor, eyesMotor,WHEEL_RADIUS, WHEEL_RADIUS,TRACK, odometer);
				usPoller = new UltrasonicPoller(usDistance, usData, driveUS) ;
				
				//start our odometer
				odometer.start();
				odometryDisplay.start();
				driveUS.start();
				usPoller.start();
				int[][] wayPoints = {{1 , 0}, {1 , 1}, {0, 2}, {2 , 2}, {1 , 1}};
				for( DriveUS.i=0 ; DriveUS.i< wayPoints.length ; DriveUS.i++){
					driveUS.travelTo(wayPoints[DriveUS.i][0], wayPoints[DriveUS.i][1]);
				}


			} else {
				Driver driver = new Driver(leftMotor, rightMotor, WHEEL_RADIUS, WHEEL_RADIUS, TRACK, odometer);
				odometer.start();
				odometryDisplay.start();
				driver.start();

			//path 1
			//driver.travelTo(0, 2);
			//driver.travelTo(1, 1);
			//driver.travelTo(2, 2);
			//driver.travelTo(2, 1);
			//driver.travelTo(1, 0);
			
			//path 2
			driver.travelTo(1, 1);
			driver.travelTo(0, 2);
			driver.travelTo(2, 2);
			driver.travelTo(2, 1);
			driver.travelTo(1, 0);
			
			//path 3
//			driver.travelTo(1, 0);
//			driver.travelTo(2, 1);
//			driver.travelTo(2, 2);
//			driver.travelTo(0, 2);
//			driver.travelTo(1, 1);
			
			//path 4
//			driver.travelTo(0, 1);
//			driver.travelTo(1, 2);
//			driver.travelTo(1, 0);
//			driver.travelTo(2, 1);
//			driver.travelTo(2, 2);
			

			// spawn a new Thread to avoid SquareDriver.drive() from blocking
//			(new Thread() {
//				public void run() {
//					Driver.travelTo(1, 1);
//				}
//			}).start();
		}

		while (Button.waitForAnyPress() != Button.ID_ESCAPE);
		System.exit(0);
	}
}
